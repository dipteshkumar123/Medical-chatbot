document.addEventListener("DOMContentLoaded", function () {
  const micButton = document.getElementById("mic-button");
  const sendButton = document.getElementById("send-button");
  const userInput = document.getElementById("user-input");
  const chatBody = document.getElementById("chat-body");

  let recognition = null;

  // 1) SET UP SPEECH-TO-TEXT (Web Speech API)
  if ("SpeechRecognition" in window || "webkitSpeechRecognition" in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      micButton.classList.add("listening");
      micButton.title = "Listening… Click again to stop.";
    };

    recognition.onend = () => {
      micButton.classList.remove("listening");
      micButton.title = "Click to speak";
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      userInput.value = transcript;
      recognition.stop();
    };

    micButton.addEventListener("click", () => {
      if (!recognition._running) {
        recognition.start();
        recognition._running = true;
      } else {
        recognition.stop();
        recognition._running = false;
      }
    });

    recognition.onend = () => {
      recognition._running = false;
      micButton.classList.remove("listening");
    };
  } else {
    // No STT support
    micButton.classList.add("disabled");
    micButton.title = "Speech recognition not supported";
  }

  // 2) FUNCTION TO APPEND A BUBBLE
  function appendBubble(role, text) {
    const wrapper = document.createElement("div");
    wrapper.classList.add("chat-message", role);

    const bubble = document.createElement("div");
    bubble.classList.add("chat-bubble");
    bubble.innerText = text;

    wrapper.appendChild(bubble);
    chatBody.appendChild(wrapper);

    // Auto-scroll to bottom
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  // 3) SEND BUTTON CLICK HANDLER
  sendButton.addEventListener("click", () => {
    const message = userInput.value.trim();
    if (!message) return;

    // 3a) Append user bubble immediately
    appendBubble("user", message);
    userInput.value = "";
    userInput.focus();

    // 3b) Send fetch request to /chat
    fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: message })
    })
      .then((resp) => resp.json())
      .then((data) => {
        if (data.error) {
          appendBubble("assistant", "⚠️ Error: " + data.error);
        } else {
          const reply = data.reply;
          appendBubble("assistant", reply);

          // 3c) Speak the AI reply in browser:
          const utterance = new SpeechSynthesisUtterance(reply);
          utterance.lang = "en-US";
          speechSynthesis.speak(utterance);
        }
      })
      .catch((err) => {
        appendBubble("assistant", "⚠️ Fetch error: " + err.message);
      });
  });

  // 4) ALLOW “Enter” key to send
  userInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault(); // Prevent newline
      sendButton.click();
    }
  });
});
