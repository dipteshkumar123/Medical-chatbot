import os
import sys
import tempfile
import nest_asyncio
import asyncio
import speech_recognition as sr
import edge_tts
from playsound import playsound
from groq import Groq
from flask import Flask, render_template, request, session, jsonify
from datetime import datetime
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph

# ─── Initialization ─────────────────────────────────────────────
nest_asyncio.apply()
client = Groq(api_key="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")

app = Flask(__name__)
# YOU MUST set a secret key to use Flask sessions:
app.secret_key = os.urandom(24)

# ─── Voice Output (TTS) for CLI mode ───────────────────────────
async def speak_text(text: str):
    """Uses edge-tts to save an mp3, plays it, then deletes the file."""
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
    file_path = temp_file.name
    temp_file.close()

    try:
        communicate = edge_tts.Communicate(text=text, voice="en-US-JennyNeural")
        await communicate.save(file_path)
        playsound(file_path)
    except Exception as e:
        print(f"⚠️ TTS error: {e}")
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)

# ─── Voice Input (STT) for CLI mode ────────────────────────────
def listen_to_user(allow_text_input: bool = True) -> str:
    """Listens on microphone (up to 10s), tries Google STT. If user says 'type', switches to keyboard."""
    recognizer = sr.Recognizer()
    recognizer.pause_threshold = 3.0
    recognizer.energy_threshold = 300

    with sr.Microphone() as source:
        print("🎤 Listening (up to 20s)... (say 'type' to use keyboard input)")
        recognizer.adjust_for_ambient_noise(source, duration=1)

        try:
            audio = recognizer.listen(source, timeout=10, phrase_time_limit=10)
            query = recognizer.recognize_google(audio)
            print(f"👤 You said: {query}\n")

            if allow_text_input and query.lower().strip() in ["type", "keyboard", "text"]:
                typed_input = input("⌨️ Please type your input: ").strip()
                print()
                return typed_input

            return query
        except sr.WaitTimeoutError:
            print("⌛ Timeout: No speech detected.")
            if allow_text_input:
                typed_input = input("⌨️ Type your input: ").strip()
                print()
                return typed_input or None
            return None
        except sr.UnknownValueError:
            print("❌ Could not understand audio.")
            if allow_text_input:
                typed_input = input("⌨️ Type your input: ").strip()
                print()
                return typed_input or None
            return None
        except sr.RequestError:
            print("❌ Speech recognition service error.")
            if allow_text_input:
                typed_input = input("⌨️ Type your input: ").strip()
                print()
                return typed_input or None
            return None
        except Exception as e:
            print(f"⚠️ Speech recognition error: {e}")
            if allow_text_input:
                typed_input = input("⌨️ Type your input: ").strip()
                print()
                return typed_input or None
            return None

# ─── Symptom Extraction & Severity Detection ───────────────────
def extract_symptoms_with_severity(text: str) -> dict:
    """Looks for keywords in `text` and returns a dict of {SymptomName: 'unknown'} initially."""
    common_symptoms = {
        "fever": "Fever",
        "cough": "Cough",
        "headache": "Headache",
        "pain": "Pain",
        "nausea": "Nausea",
        "fatigue": "Fatigue",
        "vomiting": "Vomiting",
        "dizziness": "Dizziness"
    }
    found = {}
    lower_text = text.lower()
    for key, name in common_symptoms.items():
        if key in lower_text:
            found[name] = "unknown"
    return found

async def prompt_severity(symptom: str) -> str:
    """In CLI mode, asks user to rate severity on a scale of 1–3 for `symptom`."""
    severity_levels = {"1": "Mild", "2": "Moderate", "3": "Severe"}
    prompt_text = (
        f"On a scale of 1 to 3, how severe is your {symptom}?\n"
        "1: Mild\n2: Moderate\n3: Severe\nPlease say the number..."
    )
    print(prompt_text)
    await speak_text(prompt_text)

    while True:
        response = listen_to_user(allow_text_input=True)
        if response:
            rc = response.lower().strip()
            if rc in severity_levels:
                return severity_levels[rc]
            elif rc in ["mild", "moderate", "severe"]:
                return rc.capitalize()
            else:
                print("⚠️ Please say or type 1, 2, or 3.")
                await speak_text("Please say or type 1, 2, or 3.")
        else:
            print("⚠️ Could not understand. Try again.")
            await speak_text("Could not understand. Try again.")

# ─── AI Response via Groq ─────────────────────────────────────
def get_ai_response_from_history(history: list) -> str:
    """
    history is a list of {'role': 'user' or 'assistant', 'content': '...'}
    We prepend a system prompt each time. Return the AI text.
    """
    messages = [
        {
            "role": "system",
            "content": (
                "You are a compassionate AI doctor. Respond kindly and ask follow-up questions "
                "to understand patient symptoms better. Provide personalized self-care advice "
                "and alert if medical attention is recommended."
            )
        }
    ] + history

    chat_completion = client.chat.completions.create(
        model="llama3-8b-8192",
        messages=messages
    )
    return chat_completion.choices[0].message.content

# ─── Logging & PDF Report Helpers ──────────────────────────────
def save_symptom_entry(query: str, ai_response: str, symptoms_with_severity: dict):
    """Append a block to symptom_memory.txt (time, symptoms, input, AI advice)."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("symptom_memory.txt", "a", encoding="utf-8") as f:
        f.write(f"Time: {timestamp}\n")
        if symptoms_with_severity:
            symptom_str = ", ".join(f"{sym}:{sev}" for sym, sev in symptoms_with_severity.items())
        else:
            symptom_str = "None detected"
        f.write(f"Symptoms (with severity): {symptom_str}\n")
        f.write(f"User Input: {query}\n")
        f.write(f"AI Advice: {ai_response}\n")
        f.write("-" * 40 + "\n")

def log_symptom(query: str, response: str):
    """Append a simple “User: … / AI: …” to symptom_logs.txt."""
    with open("symptom_logs.txt", "a", encoding="utf-8") as f:
        f.write(f"User: {query}\nAI: {response}\n\n")

def generate_chart():
    """Read symptom_memory.txt, calculate severity scores, and write symptom_chart.png."""
    symptom_counts = {}
    severity_score = {"Mild": 1, "Moderate": 2, "Severe": 3}

    try:
        with open("symptom_memory.txt", "r", encoding="utf-8") as f:
            lines = [L for L in f if L.startswith("Symptoms (with severity):")]
        for line in lines:
            content = line.split(":", 1)[1].strip()
            if content != "None detected":
                parts = content.split(",")
                for part in parts:
                    symp_sev = part.strip().split(":")
                    if len(symp_sev) == 2:
                        sym, sev = symp_sev
                        sym = sym.strip()
                        sev = sev.strip()
                        symptom_counts[sym] = symptom_counts.get(sym, 0) + severity_score.get(sev, 1)
    except FileNotFoundError:
        pass

    if not symptom_counts:
        symptom_counts = {"No symptoms": 1}

    plt.figure(figsize=(8, 5))
    symptoms = list(symptom_counts.keys())
    scores = list(symptom_counts.values())
    bars = plt.barh(symptoms, scores, color='coral', edgecolor='black')
    plt.title("Symptom Severity Score (Higher means more severe/frequent)", fontsize=14, fontweight='bold')
    plt.xlabel("Severity Score", fontsize=12)
    plt.ylabel("Symptoms", fontsize=12)
    plt.grid(axis='x', linestyle='--', alpha=0.7)
    plt.tight_layout()

    for bar in bars:
        width = bar.get_width()
        plt.text(width + 0.1, bar.get_y() + bar.get_height()/2, str(int(width)), va='center', fontsize=10)

    plt.savefig("symptom_chart.png", dpi=150)
    plt.close()

def generate_ai_summary() -> str:
    """
    Read the last 10 blocks from symptom_memory.txt, ask the AI for a concise summary,
    and return that summary string.
    """
    entries = []
    try:
        with open("symptom_memory.txt", "r", encoding="utf-8") as f:
            lines = f.readlines()
        block = []
        for line in lines:
            if line.strip() == "-" * 40:
                if block:
                    entries.append(" ".join(l.strip() for l in block))
                    block = []
            else:
                block.append(line)
        if block:
            entries.append(" ".join(l.strip() for l in block))
    except FileNotFoundError:
        return "No symptom data available to summarize."

    recent_entries = entries[-10:] if len(entries) > 10 else entries
    combined_text = "\n".join(recent_entries)

    prompt = (
        "You are a professional medical assistant AI. Based on the following patient symptom records, "
        "write a concise, clear summary of the patient's recent health condition, highlighting key symptoms "
        "and any notable patterns or concerns. Avoid medical jargon and keep it understandable for a layperson.\n\n"
        f"Symptom Records:\n{combined_text}\n\nSummary:"
    )

    try:
        summary = get_ai_response_from_history([{"role": "user", "content": prompt}])
    except Exception as e:
        return f"⚠️ AI summary generation error: {e}"
    return summary

def generate_styled_report():
    """
    Creates a PDF called health_report.pdf, including:
     - Title + timestamp
     - AI summary (using generate_ai_summary())
     - symptom_chart.png if it exists
     - All lines of symptom_memory.txt
    """
    pdf_path = "health_report.pdf"
    c = canvas.Canvas(pdf_path, pagesize=A4)
    width, height = A4
    styles = getSampleStyleSheet()
    normal_style = styles['Normal']

    # Title
    c.setFont("Helvetica-Bold", 24)
    c.setFillColor(colors.darkblue)
    c.drawCentredString(width/2, height - 80, "Health Report")
    c.setFont("Helvetica", 12)
    c.setFillColor(colors.black)
    c.drawCentredString(width/2, height - 100, f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    y = height - 130

    # Underline
    c.setStrokeColor(colors.darkblue)
    c.setLineWidth(2)
    c.line(50, y, width - 50, y)
    y -= 40

    # AI Summary
    ai_summary = generate_ai_summary()
    para = Paragraph("<b>AI Summary:</b><br/>" + ai_summary.replace("\n", "<br/>"), normal_style)
    w, h = para.wrap(width - 100, y)
    para.drawOn(c, 50, y - h)
    y -= h + 30

    # Symptom Chart
    if os.path.exists("symptom_chart.png"):
        chart_w = 5.5 * inch
        chart_h = 3 * inch
        c.drawImage("symptom_chart.png", 50, y - chart_h, width=chart_w, height=chart_h, preserveAspectRatio=True, mask='auto')
        y -= chart_h + 30
    else:
        c.setFont("Helvetica-Oblique", 12)
        c.setFillColor(colors.red)
        c.drawString(50, y, "⚠️ Symptom chart not found.")
        y -= 30

    # Detailed Logs
    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(colors.black)
    c.drawString(50, y, "Detailed Symptom Logs:")
    y -= 25

    line_height = 14
    try:
        with open("symptom_memory.txt", "r", encoding="utf-8") as f:
            for line in f:
                if y < 70:
                    c.showPage()
                    y = height - 50
                    c.setFont("Helvetica-Bold", 16)
                    c.drawString(50, y, "Detailed Symptom Logs (continued):")
                    y -= 25
                    c.setFont("Helvetica", 12)
                c.setFont("Helvetica", 12)
                c.setFillColor(colors.black)
                c.drawString(50, y, line.strip())
                y -= line_height
    except FileNotFoundError:
        c.setFont("Helvetica-Oblique", 12)
        c.setFillColor(colors.red)
        c.drawString(50, y, "⚠️ No recorded symptom data available.")
        y -= 20

    c.save()
    print(f"📄 Health report saved as '{pdf_path}'.")

# ─── CLI Mode (voice + text) ────────────────────────────────────
async def main():
    """
    If you call `python medical_bot.py` with no arguments,
    the CLI loop starts.  You speak, AI replies with TTS, etc.
    """
    print("👋 Welcome to AI Doctor Bot (CLI)! Speak or type 'exit' to quit.\n")
    while True:
        query = listen_to_user()
        if not query:
            await speak_text("I didn't catch that. Please try again.")
            continue

        q_lower = query.lower().strip()
        if q_lower in ["exit", "quit", "stop"]:
            print("👋 Goodbye! Stay healthy.")
            await speak_text("Goodbye! Stay healthy.")
            break

        if q_lower == "generate report":
            generate_chart()
            generate_styled_report()
            await speak_text("Health report generated as 'health_report.pdf'.")
            continue

        # Detect symptoms & ask severity
        symptoms = extract_symptoms_with_severity(query)
        if symptoms:
            for symptom in list(symptoms.keys()):
                severity = await prompt_severity(symptom)
                symptoms[symptom] = severity

        # Build conversation history just for this one-turn CLI.  (No persistent history in CLI mode.)
        history = [
            {"role": "user", "content": f"Patient reports: \"{query}\". Detected symptoms: {', '.join(f'{s} ({v})' for s, v in symptoms.items()) if symptoms else 'none'}. Respond kindly and advise."}
        ]
        ai_reply = get_ai_response_from_history(history)
        print(f"\n🤖 AI Doctor:\n{ai_reply}\n")

        # Log & save
        log_symptom(query, ai_reply)
        save_symptom_entry(query, ai_reply, symptoms)
        await speak_text(ai_reply)

# ─── Flask Web UI Integration ───────────────────────────────────
@app.route("/", methods=["GET"])
def index():
    """
    Renders the modern “Gemini-style” chat window.
    Clears session on first load (or you can keep history if you want).
    """
    session.clear()
    session['history'] = []  # Start with empty conversation
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    """
    Expects JSON: { "message": "User’s text" }
    Returns JSON: { "reply": "AI’s full answer" }
    Keeps conversation history in session['history'].
    """
    data = request.get_json()
    user_msg = data.get("message", "").strip()
    if not user_msg:
        return jsonify({"error": "Empty message"}), 400

    # Retrieve or initialize history
    history = session.get("history", [])
    # Append the new user message to history
    history.append({"role": "user", "content": user_msg})

    # Build AI context from history
    ai_reply = ""
    try:
        ai_reply = get_ai_response_from_history(history)
    except Exception as e:
        ai_reply = f"⚠️ AI error: {e}"

    # Append AI reply back into history
    history.append({"role": "assistant", "content": ai_reply})
    session["history"] = history

    # Log & store
    symptoms = extract_symptoms_with_severity(user_msg)
    # For web UI, auto-tag any detected symptoms as “Moderate” to keep it simple
    if symptoms:
        for k in symptoms:
            symptoms[k] = "Moderate"
    log_symptom(user_msg, ai_reply)
    save_symptom_entry(user_msg, ai_reply, symptoms)

    return jsonify({"reply": ai_reply})

# ─── Unified Entry Point ───────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1].lower() == "web":
        # When you run: python medical_bot.py web
        print("🚀 Starting AI Medical Bot Web Server at http://localhost:5000")
        # Make sure debug=False in production!
        app.run(host="0.0.0.0", port=5000, debug=True)
    else:
        # Default: CLI mode
        asyncio.run(main())
